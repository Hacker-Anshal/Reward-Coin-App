import {
  Coins,
  Calendar,
  Play,
  RotateCcw,
  CheckCircle,
  Target,
  LogOut,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { useApp } from "@/contexts/AppContext";

interface Task {
  id: string;
  title: string;
  reward: number;
  icon: React.ElementType;
  completed?: boolean;
}

const tasks: Task[] = [
  {
    id: "watch-ad",
    title: "Watch Ad",
    reward: Random,
    icon: Play,
  },
  {
    id: "spin-wheel",
    title: "Spin & Win",
    reward: 0, // Random amount 2-8
    icon: RotateCcw,
  },
];

export default function Home() {
  const { state, addCoins, setDailyCheckIn, addCompletedTask, logout } =
    useApp();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleDailyCheckIn = () => {
    if (!state.dailyCheckIn) {
      addCoins(25, "Daily Check-in");
      setDailyCheckIn(true);
      toast({
        title: "Daily Check-in Complete!",
        description: "+25 coins earned",
      });
    }
  };

  const handleTaskComplete = (task: Task) => {
    if (state.completedTasks.has(task.id)) return;

    if (task.id === "spin-wheel") {
      // Navigate to Spin & Win page instead of completing here
      navigate("/spin-win");
      return;
    }

    const reward = task.reward;
    addCoins(reward, task.title);
    addCompletedTask(task.id);

    toast({
      title: `${task.title} Complete!`,
      description: `+${reward} coins earned`,
    });
  };

  return (
    <div className="p-4 space-y-6 max-w-md mx-auto">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Avatar className="h-12 w-12 border-2 border-primary">
            <AvatarImage
              src={state.user?.picture || "/placeholder.svg"}
              alt="Profile"
            />
            <AvatarFallback className="bg-primary text-primary-foreground font-semibold">
              {state.user?.name
                .split(" ")
                .map((n) => n[0])
                .join("")
                .toUpperCase() || "U"}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-lg font-semibold text-foreground">
              {state.user?.name || "User"}
            </h1>
            <p className="text-sm text-muted-foreground">Welcome back!</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={logout}
          className="text-muted-foreground hover:text-foreground"
        >
          <LogOut className="h-4 w-4" />
        </Button>
      </div>

      {/* Coin Balance Card */}
      <Card className="bg-gradient-to-br from-primary/20 to-primary/5 border-primary/20 card-hover">
        <CardContent className="p-6 text-center">
          <div className="flex items-center justify-center space-x-2 mb-2">
            <Coins className="h-8 w-8 text-primary coin-spin" />
            <span className="text-3xl font-bold text-foreground">
              {state.coins.toLocaleString()}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">Total Coins</p>
        </CardContent>
      </Card>

      {/* Daily Check-in */}
      <Card className="card-hover">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-foreground">Daily Check-in</h3>
                <p className="text-sm text-muted-foreground">
                  Earn 25 coins daily
                </p>
              </div>
            </div>
            <Button
              onClick={handleDailyCheckIn}
              disabled={state.dailyCheckIn}
              size="sm"
              className={
                state.dailyCheckIn ? "bg-success hover:bg-success" : ""
              }
            >
              {state.dailyCheckIn ? (
                <>
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Done
                </>
              ) : (
                "Check-in"
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tasks Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground flex items-center">
          <Target className="h-5 w-5 mr-2 text-primary" />
          Earn More Coins
        </h2>

        <div className="space-y-3">
          {tasks.map((task) => {
            const Icon = task.icon;
            const isCompleted = state.completedTasks.has(task.id);

            return (
              <Card key={task.id} className="card-hover">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium text-foreground">
                          {task.title}
                        </h3>
                        <div className="flex items-center space-x-2">
                          {task.id === "spin-wheel" ? (
                            <Badge variant="secondary" className="text-xs">
                              2-8 coins
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="text-xs">
                              +{task.reward} coins
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleTaskComplete(task)}
                      disabled={isCompleted}
                      size="sm"
                      variant={isCompleted ? "secondary" : "default"}
                      className={
                        isCompleted
                          ? "bg-success hover:bg-success text-success-foreground"
                          : ""
                      }
                    >
                      {isCompleted ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Done
                        </>
                      ) : (
                        "Start"
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
