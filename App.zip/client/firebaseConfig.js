// Firebase configuration and initialization
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCMYrPBDKa44vMseGWHb8TGgek2_Mi2wIw",
  authDomain: "reward-coins-app-a9af0.firebaseapp.com",
  projectId: "reward-coins-app-a9af0",
  storageBucket: "reward-coins-app-a9af0.firebasestorage.app",
  messagingSenderId: "590301179268",
  appId: "1:590301179268:web:8ba2138b990f0893f441d1"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export function signInWithGoogle() {
  return signInWithPopup(auth, provider);
}

export const db = getFirestore(app);
